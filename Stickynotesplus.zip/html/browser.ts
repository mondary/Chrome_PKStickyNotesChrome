//browser related files
import { getAllNotes, removeNote } from "../stickies";

chrome.storage.local.getBytesInUse().then((bytes) => {
  chrome.storage.sync.getBytesInUse().then((sbytes) => {
    const el = document.createElement("p");
    const total =
      chrome.storage.sync.QUOTA_BYTES + chrome.storage.local.QUOTA_BYTES;
    el.innerText = String(bytes + sbytes) + "/" + total;
    document.body.appendChild(el);
  });
});

loadPage(1);

function loadPage(page: number) {
  const itemsPerPage = 2;
  getAllNotes().then((notes) => {
    //group by url
    notes.sort((a, b) => {
      if (a.url < b.url) {
        return -1;
      }
      if (a.url > b.url) {
        return 1;
      }
      return 0;
    });

    createTable(notes);
  });
}

function createTable(notes: Note[]) {
  // names must be equal)
  const table: HTMLTableElement = document.createElement("table");
  const headerRow = table.insertRow();
  ["Url", "Text", ""].forEach((headerText) => {
    const th = document.createElement("th");
    th.textContent = headerText;
    headerRow.appendChild(th);
  });

  notes.forEach((note) => {
    const row = table.insertRow();
    const link = document.createElement("a");
    link.href = note.url;
    link.innerText = note.url;
    const del = document.createElement("a");

    del.onclick = () => {
      removeNote(note.id);
      row.remove();
    };

    del.innerText = "Delete";
    del.style.cursor = "pointer";

    row.insertCell().appendChild(link);
    row.insertCell().textContent = note.text;
    row.insertCell().appendChild(del);
  });

  table.style.textAlign = "left";
  document.getElementById("notes").appendChild(table);
}
