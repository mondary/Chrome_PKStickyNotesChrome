const saveOptions = () => {
  const analytics = document.getElementById("analytics") as HTMLInputElement;
  const analyticsEnabled = analytics.checked;

  chrome.storage.sync.set({ analyticsEnabled: analyticsEnabled }, () => {
    const status = document.getElementById("status");
    status.textContent = "Options saved.";
    setTimeout(() => {
      status.textContent = "";
    }, 750);
  });
};

const restoreOptions = () => {
  chrome.storage.sync.get({ analyticsEnabled: true }, (prefs) => {
    const analytics = document.getElementById("analytics") as HTMLInputElement;
    analytics.checked = prefs.analyticsEnabled;
  });
};

document.addEventListener("DOMContentLoaded", restoreOptions);
document.getElementById("save").addEventListener("click", saveOptions);
