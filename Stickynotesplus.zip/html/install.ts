import { isPaid, launchGoogleAuthFlow } from "../background/auth";

document.addEventListener("DOMContentLoaded", async (e) => {
  const el = document.getElementById("upgrade");

  el.onclick = async (e) => {
    el.classList.add("button--loading");
    const paid = await isPaid().catch((err) => false);
    if (paid) {
      alert("You already paid for this item");
    }

    launchGoogleAuthFlow({
      onSuccess: (user_id: string) => {
        window.open(
          `https://buy.stripe.com/8wMdSb0Fu5qtdWw5kl?client_reference_id=${user_id}`
        );
        el.classList.remove("button--loading");
      },
      onError: () => {
        el.classList.remove("button--loading");
        alert("Something went wrong... Please try again");
      },
      onCancel: () => {
        el.classList.remove("button--loading");
      },
    });
  };
});
