/******/ (() => { // webpackBootstrap
/*!****************************!*\
  !*** ./src/share/share.ts ***!
  \****************************/
var button = document.getElementById("action");
var title = document.getElementById("title");
var subtext = document.getElementById("subtext");
var url = document.getElementById("url");
var link = url.href;
if (!button || !title || !subtext) {
    throw "share.html and content script out of sync";
}
//get the url
title.innerText = "You've been shared sticky notes";
button.innerText = "View Notes";
subtext.innerText = "Notes are deleted after 24h.";
button.href = "#";
button.onclick = function () {
    var params = new URL(document.location.href).searchParams;
    var id = params.get("n");
    chrome.runtime.sendMessage({ message: "move", url: link, list_id: id });
};

/******/ })()
;
//# sourceMappingURL=share.js.map