/******/ (() => { // webpackBootstrap
/*!*****************************!*\
  !*** ./src/html/options.ts ***!
  \*****************************/
var saveOptions = function () {
    var analytics = document.getElementById("analytics");
    var analyticsEnabled = analytics.checked;
    chrome.storage.sync.set({ analyticsEnabled: analyticsEnabled }, function () {
        var status = document.getElementById("status");
        status.textContent = "Options saved.";
        setTimeout(function () {
            status.textContent = "";
        }, 750);
    });
};
var restoreOptions = function () {
    chrome.storage.sync.get({ analyticsEnabled: true }, function (prefs) {
        var analytics = document.getElementById("analytics");
        analytics.checked = prefs.analyticsEnabled;
    });
};
document.addEventListener("DOMContentLoaded", restoreOptions);
document.getElementById("save").addEventListener("click", saveOptions);

/******/ })()
;
//# sourceMappingURL=options.js.map