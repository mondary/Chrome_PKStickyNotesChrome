/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/stickies/index.ts":
/*!*******************************!*\
  !*** ./src/stickies/index.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   exportNotes: () => (/* reexport safe */ _storage__WEBPACK_IMPORTED_MODULE_0__.exportNotes),
/* harmony export */   getAllNotes: () => (/* reexport safe */ _storage__WEBPACK_IMPORTED_MODULE_0__.getAllNotes),
/* harmony export */   removeNote: () => (/* reexport safe */ _storage__WEBPACK_IMPORTED_MODULE_0__.removeNote),
/* harmony export */   saveNote: () => (/* reexport safe */ _storage__WEBPACK_IMPORTED_MODULE_0__.saveNote)
/* harmony export */ });
/* harmony import */ var _storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./storage */ "./src/stickies/storage.ts");




/***/ }),

/***/ "./src/stickies/storage.ts":
/*!*********************************!*\
  !*** ./src/stickies/storage.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   exportNotes: () => (/* binding */ exportNotes),
/* harmony export */   getAllNotes: () => (/* binding */ getAllNotes),
/* harmony export */   removeNote: () => (/* binding */ removeNote),
/* harmony export */   saveNote: () => (/* binding */ saveNote)
/* harmony export */ });
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var storage = chrome.storage.local;
function saveFile(textContent, fileName) {
    var blob = new Blob([textContent], { type: "text/plain" });
    var anchor = document.createElement("a");
    anchor.style.display = "none";
    anchor.download = fileName;
    var url = window.URL.createObjectURL(blob);
    anchor.href = url;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    window.URL.revokeObjectURL(url);
}
function removeNote(id) {
    chrome.runtime.sendMessage({ message: "analytics", type: "note-deleted" });
    storage.get({ savedNotes: [] }, function (result) {
        var notes = result.savedNotes;
        var index = notes.findIndex(function (note) { return note.id == id; });
        if (index > -1) {
            notes.splice(index, 1);
        }
        storage.set({ savedNotes: notes }, function () { });
    });
}
function getAllNotes(url) {
    return __awaiter(this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            return [2 /*return*/, new Promise(function (resolve, reject) {
                    storage.get({ savedNotes: [] }, function (result) {
                        if (chrome.runtime.lastError) {
                            reject(chrome.runtime.lastError);
                        }
                        else {
                            if (url) {
                                var filtered = result.savedNotes.filter(function (note) { return note.url === url; });
                                resolve(filtered);
                            }
                            else {
                                resolve(result.savedNotes);
                            }
                        }
                    });
                })];
        });
    });
}
function saveNote(old_note) {
    return __awaiter(this, void 0, void 0, function () {
        var result, notes, index, message, error_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, storage.get({ savedNotes: [] })];
                case 1:
                    result = _a.sent();
                    notes = result.savedNotes || [];
                    index = notes.findIndex(function (note) { return note.id === old_note.id; });
                    if (index > -1) {
                        notes.splice(index, 1);
                    }
                    index = notes.findIndex(function (note) { return note.x === old_note.x && note.y == old_note.y; });
                    if (index > -1) {
                        notes.splice(index, 1);
                    }
                    notes.push({
                        id: old_note.id,
                        url: old_note.url,
                        x: old_note.x,
                        y: old_note.y,
                        text: old_note.text,
                    });
                    message = "";
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, storage.set({ savedNotes: notes })];
                case 3:
                    _a.sent();
                    return [3 /*break*/, 5];
                case 4:
                    error_1 = _a.sent();
                    message = "Out of space";
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/, message];
            }
        });
    });
}
function exportNotes(url, filename) {
    getAllNotes(url).then(function (notes) {
        var body = "Url: " + url + "\n";
        body += serializeNotes(notes);
        saveFile(body, filename);
    });
}
function serializeNote(note) {
    var pos = "(".concat(note.x, ",").concat(note.y, ")");
    return "".concat(pos, ": ").concat(note.text);
}
function serializeNotes(notes) {
    if (notes.length == 0) {
        return "No notes to save";
    }
    var result = "";
    result += "Last updated: ".concat(new Date().toLocaleTimeString("en-US", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
    }), "\n\n");
    notes.forEach(function (note) {
        result += serializeNote(note) + "\n";
    });
    return result;
}



/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/*!*****************************!*\
  !*** ./src/html/browser.ts ***!
  \*****************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _stickies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../stickies */ "./src/stickies/index.ts");
//browser related files

chrome.storage.local.getBytesInUse().then(function (bytes) {
    chrome.storage.sync.getBytesInUse().then(function (sbytes) {
        var el = document.createElement("p");
        var total = chrome.storage.sync.QUOTA_BYTES + chrome.storage.local.QUOTA_BYTES;
        el.innerText = String(bytes + sbytes) + "/" + total;
        document.body.appendChild(el);
    });
});
loadPage(1);
function loadPage(page) {
    var itemsPerPage = 2;
    (0,_stickies__WEBPACK_IMPORTED_MODULE_0__.getAllNotes)().then(function (notes) {
        //group by url
        notes.sort(function (a, b) {
            if (a.url < b.url) {
                return -1;
            }
            if (a.url > b.url) {
                return 1;
            }
            return 0;
        });
        createTable(notes);
    });
}
function createTable(notes) {
    // names must be equal)
    var table = document.createElement("table");
    var headerRow = table.insertRow();
    ["Url", "Text", ""].forEach(function (headerText) {
        var th = document.createElement("th");
        th.textContent = headerText;
        headerRow.appendChild(th);
    });
    notes.forEach(function (note) {
        var row = table.insertRow();
        var link = document.createElement("a");
        link.href = note.url;
        link.innerText = note.url;
        var del = document.createElement("a");
        del.onclick = function () {
            (0,_stickies__WEBPACK_IMPORTED_MODULE_0__.removeNote)(note.id);
            row.remove();
        };
        del.innerText = "Delete";
        del.style.cursor = "pointer";
        row.insertCell().appendChild(link);
        row.insertCell().textContent = note.text;
        row.insertCell().appendChild(del);
    });
    table.style.textAlign = "left";
    document.getElementById("notes").appendChild(table);
}

/******/ })()
;
//# sourceMappingURL=browser.js.map